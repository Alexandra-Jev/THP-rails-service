require 'twitter'

class SendTweet

  def initialize(tweet_content)

client = Twitter::REST::Client.new do |config|
  config.consumer_key        = "f8Q8xzG7xKn8aazTXmUmB"
  config.consumer_secret     = "YJDce0LpbtALYioljQTaqJMtLdwxADiZmb43m9JP1ye"
  config.access_token        = "855135546-broeWd9IQcadmK4gKFI5"
  config.access_token_secret = "OoUP1kRSBklenooiUa6c2S7yO5AgjZeHVfilRf1a"
  end
end

def send_tweet
  @client.update("Hello World")
end
end
