class TableMovies < ActiveRecord::Migration[5.1]
  def change
    create_table :movies
    add_column :movies, :title, :string
    add_column :movies, :date_de_sortie, :datetime
    add_column :movies, :realisateur, :string 
  end
end
