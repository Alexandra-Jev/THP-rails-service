class MoviesController < ApplicationController
  def index
    @les_films = Movie.all
  end

def create
  Movie.create title: params[:title]
  redirect_to "/movies"
end
end
